GTA San Andreas MC (Forge 1.21.1) - Tahap 1

Tiga kota sebagai dimensi: Los Santos (siang, beton abu), San Fierro (senja, abu terang),
Las Venturas (malam, gurun). Tiga kunci: klik kanan = pergi ke kota / kembali ke Overworld.
Resep (ring 8 bahan + ender pearl di tengah): Los Santos=emas, San Fierro=besi, Las Venturas=redstone.
Atau: /give @s gtasa:san_fierro_key

KOMPILASI (butuh PC + JDK 21):
1. Unduh Forge MDK 1.21.1 resmi, salin folder "src" dari sini ke MDK (timpa).
2. Di gradle.properties MDK, set mod_id=gtasa.
3. ./gradlew build  ->  build/libs/gtasa-0.1.0.jar  ->  taruh di folder mods.
Mod ini terpisah dari mod gtamc, jangan dipasang bersamaan di satu langkah kompilasi yang sama.
