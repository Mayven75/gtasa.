package com.gtasa;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

/** Klik kanan: pergi ke kota tujuan; kalau sudah di kota itu, kembali ke Overworld. */
public class CityKeyItem extends Item {
    private final String cityId;
    private final ResourceKey<Level> target;

    public CityKeyItem(Properties properties, String cityId) {
        super(properties);
        this.cityId = cityId;
        this.target = ResourceKey.create(Registries.DIMENSION,
                ResourceLocation.fromNamespaceAndPath(GtaSa.MODID, cityId));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide && player instanceof ServerPlayer sp && sp.getServer() != null) {
            boolean leaving = level.dimension().equals(target);
            ServerLevel dest = sp.getServer().getLevel(leaving ? Level.OVERWORLD : target);

            if (dest != null) {
                BlockPos base = leaving ? dest.getSharedSpawnPos() : BlockPos.ZERO;
                BlockPos top = dest.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, base);
                sp.teleportTo(dest, top.getX() + 0.5, top.getY(), top.getZ() + 0.5,
                        sp.getYRot(), sp.getXRot());
                sp.getCooldowns().addCooldown(this, 60);
                sp.displayClientMessage(leaving
                        ? Component.translatable("msg.gtasa.leave")
                        : Component.translatable("msg.gtasa.welcome",
                                Component.translatable("city.gtasa." + cityId)), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
