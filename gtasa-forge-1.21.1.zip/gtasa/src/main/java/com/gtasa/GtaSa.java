package com.gtasa;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(GtaSa.MODID)
public class GtaSa {
    public static final String MODID = "gtasa";

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    public static final RegistryObject<Item> LOS_SANTOS_KEY = ITEMS.register("los_santos_key",
            () -> new CityKeyItem(new Item.Properties().stacksTo(1), "los_santos"));
    public static final RegistryObject<Item> SAN_FIERRO_KEY = ITEMS.register("san_fierro_key",
            () -> new CityKeyItem(new Item.Properties().stacksTo(1), "san_fierro"));
    public static final RegistryObject<Item> LAS_VENTURAS_KEY = ITEMS.register("las_venturas_key",
            () -> new CityKeyItem(new Item.Properties().stacksTo(1), "las_venturas"));

    public GtaSa() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        bus.addListener(this::addCreative);
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(LOS_SANTOS_KEY);
            event.accept(SAN_FIERRO_KEY);
            event.accept(LAS_VENTURAS_KEY);
        }
    }
}
